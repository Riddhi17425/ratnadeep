@extends('front.layouts.main')

@section('title', 'Contact Us | Ratnadeep Metal & Tubes Ltd.')

@section('page_css')
<link rel="stylesheet" href="{{ asset('frontend/assets/css/contact.css') }}">
@endsection

@section('content')
<main class="page-contact">
    <!-- Hero -->
    <section class="inner-hero-section inner-hero-section--contact container-fluid position-relative p-0">
        <div class="inner-hero-bg h-100 position-relative">
            <div class="inner-hero-media" aria-hidden="true">
                <img src="{{ asset('frontend/assets/images/Contact/contact-hero.png') }}" alt="" class="inner-hero-image">
                <div class="inner-hero-overlay"></div>
            </div>
            <div class="container hero-content-wrapper h-100 position-relative">
                <div class="hero-content">
                    <div class="hero-badge">
                        <span class="badge-dot"></span>
                        <span>CONNECT WITH US</span>
                    </div>
                    <h1 class="hero-title">Your Manufacturing Requirement.<br>Our Commitment.</h1>
                    <p class="hero-subtitle">Reach out to Ratnadeep Metal And Tubes Limited for pipe and tube manufacturing solutions, technical support, or project enquiries. From product selection to timely delivery, our team is here to help.</p>
                    <div class="hero-buttons">
                        <a href="#write-to-us" class="com_btn_red">Request a Technical Quote <span class="ms-2"><svg width="20" height="9" viewBox="0 0 20 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 0.75L18.75 4.5L15 8.25M18.75 4.5H0.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
                        <a href="{{ route('products') }}" class="com_btn_outline_white">Explore Products</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Write To Us -->
    <section class="mt_80" id="write-to-us">
        <div class="container">
            <div class="contact-form-grid">
                <div class="contact-form-col">
                    <div class="contact-form-intro">
                        <div class="section-badge align-left">
                            <span class="badge-dot purple-dot"></span>
                            WRITE TO US
                        </div>
                        <h2 class="section-title text-start contact-form-title">Let's Discuss Your Requirements</h2>
                    </div>
                    <form id="contactInquiryForm"
                        class="contact-form"
                        action="{{ route('contact.submit') }}"
                        method="POST"
                        novalidate>
                        @csrf
                        <input type="hidden" name="inquiry_type" value="page">

                        <div id="contactFormMessage" class="mb-3" role="alert" aria-live="polite"></div>

                        <div class="contact-form-row">
                            <div class="contact-field">
                                <input type="text"
                                    name="name"
                                    id="full_name"
                                    placeholder="Full Name*:"
                                    value="{{ old('name') }}"
                                    maxlength="255"
                                    required>
                                    <span class="text-danger field-error" data-error-for="name"></span>
                                @error('name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="contact-field">
                                <input type="text"
                                    name="company"
                                    id="company_name"
                                    placeholder="Company Name*:"
                                    value="{{ old('company') }}"
                                    maxlength="255"
                                    required>
                                    <span class="text-danger field-error" data-error-for="company"></span>
                                @error('company')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="contact-form-row">
                            <div class="contact-field">
                                <input type="email"
                                    name="email"
                                    id="email"
                                    placeholder="Email Address*:"
                                    value="{{ old('email') }}"
                                    maxlength="255"
                                    required>
                                    <span class="text-danger field-error" data-error-for="email"></span>
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="contact-field">
                                <input type="tel"
                                    name="phone"
                                    id="phone"
                                    placeholder="Phone Number*:"
                                    value="{{ old('phone') }}"
                                    maxlength="50"
                                    required>
                                    <span class="text-danger field-error" data-error-for="phone"></span>
                                @error('phone')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="contact-form-row">
                            <div class="contact-field contact-field--select">
                                <select name="country" id="country" required>
                                    <option value="">Select Country*:</option>

                                    @foreach ($countries as $country)
                                        <option value="{{ $country->name }}"
                                            {{ old('country') == $country->name ? 'selected' : '' }}>
                                            {{ $country->name }}
                                        </option>
                                    @endforeach
                                </select>

                                <span class="text-danger field-error" data-error-for="country"></span>

                                @error('country')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            
                            <div class="contact-field">
                                <input type="text"
                                    name="city"
                                    id="city"
                                    placeholder="City*:"
                                    value="{{ old('city') }}"
                                    required>
                                    <span class="text-danger field-error" data-error-for="city"></span>
                                @error('city')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="contact-form-row contact-row-full">
                            <div class="contact-field contact-field-full contact-field--select">
                                <select name="product" id="product">
                                    <option value="">Select Product</option>

                                    @foreach ($products as $product)
                                        <option value="{{ $product->title }}"
                                            {{ old('product') === $product->title ? 'selected' : '' }}>
                                            {{ $product->title }}
                                        </option>
                                    @endforeach

                                    <option value="Other"
                                        {{ old('product') === 'Other' ? 'selected' : '' }}>
                                        Other
                                    </option>
                                </select>
                                <span class="text-danger field-error" data-error-for="product"></span>
                                @error('product')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="contact-form-row contact-row-full">
                            <div class="contact-field">
                                <textarea name="requirement_details"
                                    id="requirement"
                                    placeholder="Requirement:"
                                    maxlength="10000">{{ old('requirement_details') }}</textarea>
                                    <span class="text-danger field-error" data-error-for="requirement_details"></span>
                                @error('requirement_details')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        @if ($errors->any())
                            <div class="text-danger mb-3">
                                Please correct the errors above and submit again.
                            </div>
                        @endif

                        @if (session('error'))
                            <div class="text-danger mb-3">
                                {{ session('error') }}
                            </div>
                        @endif

                        <div class="contact-form-actions">
                            <button type="submit" class="com_btn_red contact-submit-btn">
                                Submit
                                <span class="ms-2">
                                    <svg width="20" height="9" viewBox="0 0 20 9"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15 0.75L18.75 4.5L15 8.25M18.75 4.5H0.75"
                                            stroke="currentColor" stroke-width="1.5"
                                            stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </span>
                            </button>
                        </div>
                    </form>                    
                </div>
                <div class="contact-map-col">
                    <div class="contact-map-wrap">
                        <iframe 
                            class="contact-map-iframe" title="Ratnadeep Metal And Tubes Location - Mumbai" src="https://maps.google.com/maps?q=110%2C%20Gujrat%2C%20196%2F198%2C%20Khetwadi%20Back%20Road%2C%20Opp.%2013th%20Khetwadi%20Lane%2C%20Mumbai%20-%20400%20004%2C%20India&hl=en&z=16&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen>
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Reach Us -->
    <section class="mt_80 contact-locations-section">
        <div class="container">
            <div class="text-center section-header-gap">
                <div class="section-badge">
                    <span class="badge-dot purple-dot"></span>
                    REACH US
                </div>
                <h2 class="section-title">Our Locations &amp; Contacts</h2>
            </div>
            <div class="contact-locations-grid">
                <div class="contact-location-card">
                    <h3 class="contact-location-title">Registered Office</h3>
                    <p class="contact-location-address"><a href="https://www.google.com/maps/search/?api=1&query=402+Sai+Prasad+Apartment+Usmanpura+Ahmedabad+380013+Gujarat+India" target="_blank" rel="noopener">402, Sai Prasad Apartment, Usmanpura, Ahmedabad – 380 013, Gujarat, India.</a></p>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Contact us:</span>
                        <a href="tel:+918238092054" target="_blank">+91 82380 92054</a>
                    </div>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Email us:</span>
                        <a href="mailto:ro@ratnadeepmetal.com" target="_blank">ro@ratnadeepmetal.com</a>
                    </div>
                </div>
                <div class="contact-location-card">
                    <h3 class="contact-location-title">Corporate Office:</h3>
                    <p class="contact-location-address"><a href="https://www.google.com/maps/search/?api=1&query=102+Rajgiri+196%2F198+Khetwadi+Back+Road+Mumbai+400004+Maharashtra+India" target="_blank" rel="noopener">102, "Rajgiri", 196/198, Khetwadi Back Road, Mumbai – 400 004, Maharashtra, India.</a></p>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Contact us:</span>
                        <a href="tel:02266362742" target="_blank">022-66362742</a>
                    </div>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Email us:</span>
                        <a href="mailto:info@ratnadeepmetal.com" target="_blank">info@ratnadeepmetal.com</a>
                    </div>
                </div>
                <div class="contact-location-card">
                    <h3 class="contact-location-title">Manufacturing site:</h3>
                    <p class="contact-location-address"><a href="https://www.google.com/maps/search/?api=1&query=Survey+No+1015+Village+Rajpur+Taluka+Kadi+District+Mehsana+382715+Gujarat+India" target="_blank" rel="noopener">Survey No. 1015, Village Rajpur, Taluka Kadi, District Mehsana - 382 715, Gujarat, India.</a></p>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Contact us:</span>
                        <a href="tel:+919724303768" target="_blank">+91 97243 03768</a>
                    </div>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Email us:</span>
                        <a href="mailto:works@ratnadeepmetal.com" target="_blank">works@ratnadeepmetal.com</a>
                    </div>
                </div>
                <div class="contact-location-card">
                    <h3 class="contact-location-title">Europe Sales:</h3>
                    <p class="contact-location-address"><a href="https://www.google.com/maps/search/?api=1&query=Gritec+Metals+S.L.+Calle+Barroso+6+29001+M%C3%A1laga+Spain" target="_blank" rel="noopener">Gritec Metals, S.L. Calle Barroso 6, 3a 29001 Málaga Spain</a></p>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Contact us:</span>
                        <a href="tel:+34656727439" target="_blank">+34 656 727439</a>
                    </div>
                    <div class="contact-location-meta">
                        <span class="contact-location-label">Email us:</span>
                        <a href="mailto:sales@gritecmetals.com" target="_blank">sales@gritecmetals.com</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Careers -->
    <!-- <section class="mt_80 contact-careers-section">
        <div class="container">
            <div class="text-center section-header-gap">
                <div class="section-badge">
                    <span class="badge-dot purple-dot"></span>
                    Careers at Ratnadeep
                </div>
                <h2 class="section-title">Careers at Ratnadeep</h2>
                <p class="contact-careers-lead">Bring your expertise to a team driven by engineering precision, manufacturing discipline, and continuous improvement.</p>
                <a href="#write-to-us" class="com_btn_red">Join Our Team <span class="ms-2"><svg width="20" height="9" viewBox="0 0 20 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 0.75L18.75 4.5L15 8.25M18.75 4.5H0.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>
            </div>
            <div class="contact-careers-gallery">
                <div class="contact-career-card contact-career-card--left">
                    <img src="{{ asset('frontend/assets/images/About/career-1.png') }}" alt="Ratnadeep team meeting" class="img-fluid w-100">
                </div>
                <div class="contact-career-card contact-career-card--center">
                    <img src="{{ asset('frontend/assets/images/About/career-2.png') }}" alt="" class="contact-career-layer contact-career-layer--bg" aria-hidden="true">
                    <img src="{{ asset('frontend/assets/images/About/career-2-overlay.png') }}" alt="Ratnadeep workforce at manufacturing facility" class="contact-career-layer contact-career-layer--fg">
                </div>
                <div class="contact-career-card contact-career-card--right">
                    <img src="{{ asset('frontend/assets/images/About/career-3.png') }}" alt="Ratnadeep team collaboration" class="img-fluid w-100">
                </div>
            </div>
        </div>
    </section> -->
</main>

<script>
(function () {
    function initializeContactForm() {
        const form = document.getElementById('contactInquiryForm');

        if (!form || form.dataset.ajaxInitialized === 'true') {
            return;
        }

        const submitButton = form.querySelector('.contact-submit-btn');
        const messageBox = document.getElementById('contactFormMessage');

        if (!submitButton || !messageBox) {
            console.error('Contact form elements are missing.');
            return;
        }

        form.dataset.ajaxInitialized = 'true';

        function clearErrors() {
            form.querySelectorAll('.field-error').forEach(function (element) {
                element.textContent = '';
            });

            form.querySelectorAll('.is-invalid').forEach(function (element) {
                element.classList.remove('is-invalid');
            });

            messageBox.textContent = '';
            messageBox.className = 'mb-3';
        }

        function showMessage(message, type) {
            messageBox.textContent = message;
            messageBox.className =
                'mb-3 ' + (type === 'success' ? 'text-success' : 'text-danger');
        }

        function showErrors(errors) {
            Object.keys(errors).forEach(function (fieldName) {
                const field = Array.from(form.elements).find(function (element) {
                    return element.name === fieldName;
                });

                const errorContainer = Array.from(
                    form.querySelectorAll('[data-error-for]')
                ).find(function (element) {
                    return element.getAttribute('data-error-for') === fieldName;
                });

                if (errorContainer) {
                    errorContainer.textContent = errors[fieldName][0];
                }

                if (field) {
                    field.classList.add('is-invalid');
                }
            });
        }

        function clearFieldError(field) {
            if (!field || !field.name) return;

            const errorContainer = Array.from(
                form.querySelectorAll('[data-error-for]')
            ).find(function (element) {
                return element.getAttribute('data-error-for') === field.name;
            });

            if (errorContainer) {
                errorContainer.textContent = '';
            }

            field.classList.remove('is-invalid');
        }

        form.addEventListener('input', function (event) {
            clearFieldError(event.target);
        });

        form.addEventListener('change', function (event) {
            clearFieldError(event.target);
        });

        form.addEventListener('submit', async function (event) {
            event.preventDefault();

            if (submitButton.disabled) return;

            clearErrors();

            const originalButtonText = submitButton.innerHTML;

            submitButton.disabled = true;
            submitButton.innerHTML = 'Submitting...';

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin'
                });

                const contentType = response.headers.get('content-type') || '';

                if (!contentType.includes('application/json')) {
                    throw new Error(
                        'The server did not return JSON. Check the Laravel response.'
                    );
                }

                const result = await response.json();

                if (response.status === 422) {
                    showErrors(result.errors || {});

                    showMessage(
                        result.message ||
                        'Please correct the errors and try again.',
                        'error'
                    );

                    // Do not force scrolling or focus the first field.
                    return;
                }

                if (!response.ok || !result.success) {
                    showMessage(
                        result.message ||
                        'Unable to submit your enquiry. Please try again.',
                        'error'
                    );

                    return;
                }

                showMessage(
                    result.message || 'Enquiry submitted successfully.',
                    'success'
                );

                window.location.assign(@json(route('thankyou')));

            } catch (error) {
                console.error('Contact form submission failed:', error);

                showMessage(
                    'A network or server error occurred. Please try again.',
                    'error'
                );

            } finally {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            initializeContactForm,
            { once: true }
        );
    } else {
        initializeContactForm();
    }
})();
</script>
@endsection